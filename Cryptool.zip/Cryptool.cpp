#include "Cryptool.h"
#include "des.h"
#include "aes.h"

#define get_cstr(qstr) qstr.toLatin1().data()


Cryptool::Cryptool(QWidget* parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	ui.statusLabel->setText(QString("就绪。"));
	ui.keyInput->setText(QString("ABCDEFGH"));
	ui.plainLine->setReadOnly(true);
	ui.cipherLine->setReadOnly(true);
	ui.keyLine->setReadOnly(true);
	setWindowTitle("DES/AES加解密工具-V2");
	connect(ui.pButton, &QPushButton::pressed, this, &Cryptool::selectPlainFile);
	connect(ui.cButton, &QPushButton::pressed, this, &Cryptool::selectCipherFile);
	connect(ui.kButton, &QPushButton::pressed, this, &Cryptool::selectKeyFile);
	connect(ui.encryptBtn, &QPushButton::pressed, this, &Cryptool::startEncrypt);
	connect(ui.decryptBtn, &QPushButton::pressed, this, &Cryptool::startDecrypt);
}

Cryptool::~Cryptool()
{}

void Cryptool::yield(QString text) {
	ui.statusLabel->setText(text);
}

void Cryptool::yield(const char* text) {
	QString txt(text);
	ui.statusLabel->setText(txt);
}

QString Cryptool::selectFile() {
	return QFileDialog::getOpenFileName(
		this, QStringLiteral("文件对话框！"),
		"F:",
		QStringLiteral("明/密文文件(*txt)")
	);
}

void Cryptool::selectPlainFile() {
	plainFile = QFileInfo(selectFile());
	ui.plainLine->setText(plainFile.fileName());
}

void Cryptool::selectCipherFile() {
	cipherFile = QFileInfo(selectFile());
	ui.cipherLine->setText(cipherFile.fileName());
}

void Cryptool::selectKeyFile() {
	keyFile = QFileInfo(selectFile());
	ui.keyLine->setText(keyFile.fileName());
	loadDesKey();
}

void Cryptool::startEncrypt() {
	if (!plainFile.exists()) {
		yield("错误：明文文件不存在！");
		return;
	}
	QString output = plainFile.absolutePath() +
		"/" +
		plainFile.fileName().split('.')[0] +
		"_encrypt.txt";
	bool success;
	if (crypMode == CrypMode::DESmode) {
		success = encryptDes(get_cstr(plainFile.absoluteFilePath()),
			get_cstr(output),
			desKey);
	}
	else {
		success = encryptAes(get_cstr(plainFile.absoluteFilePath()),
			get_cstr(output),
			aesKey);
	}
	if (success) yield("加密成功！");
}

void Cryptool::startDecrypt() {
	if (!cipherFile.exists()) {
		yield("错误：密文文件不存在！");
		return;
	}
	QString output = cipherFile.absolutePath() +
		"/" +
		cipherFile.fileName().split('.')[0] +
		"_decrypt.txt";
	bool success;
	if (crypMode == CrypMode::DESmode) {
		success = decryptDes(
			get_cstr(cipherFile.absoluteFilePath()),
			get_cstr(output),
			desKey
		);
	}
	else {
		success = decryptAes(
			get_cstr(cipherFile.absoluteFilePath()),
			get_cstr(output),
			aesKey
		);
	}
	if (success) yield("解密成功！");
}

void Cryptool::loadDesKey() {
	FILE* kf = fopen(get_cstr(keyFile.absoluteFilePath()), "r");
	int cnt = fread(desKey, 1, 8, kf);
	if (cnt < 8) yield("错误：密钥文件不可用！");
	else {
		yield("密钥加载成功！");
		QString qkey;
		for (int i = 0; i < 8; i++) qkey.append((char)desKey[i]);
		qkey.append('\0');
		ui.keyInput->setText(qkey);
	}
}

bool Cryptool::checkDesKey() {
	QString text = ui.keyInput->text();
	if (text.size() >= 8) {
		for (int i = 0; i < 8; i++)
			desKey[i] = (unsigned char)text[i].toLatin1();
		return true;
	}
	yield("错误：密钥长度错误。");
	return false;
}

void Cryptool::loadAesKey() {
	FILE* kf = fopen(get_cstr(keyFile.absoluteFilePath()), "r");
	int cnt = fread(aesKey, 1, 16, kf);
	if (cnt < 16) yield("错误：密钥文件不可用！");
	else {
		yield("密钥加载成功！");
		QString qkey;
		for (int i = 0; i < 16; i++) qkey.append((char)aesKey[i]);
		qkey.append('\0');
		ui.keyInput->setText(qkey);
	}
}

bool Cryptool::checkAesKey() {
	QString text = ui.keyInput->text();
	if (text.size() >= 16) {
		for (int i = 0; i < 16; i++)
			aesKey[i] = (unsigned char)text[i].toLatin1();
		return true;
	}
	yield("错误：密钥长度错误。");
	return false;
}

bool Cryptool::encryptDes(const char* pt_path, const char* ct_path, unsigned char* key) {
	if (!checkDesKey()) {
		return false;
	}
	symmetric_key skey;
	if (des_setup(key, 8, 16, &skey) == CRYPT_OK) {
		unsigned char plain[8];
		unsigned char cipher[8];
		FILE* pf = fopen(pt_path, "rb");
		FILE* cf = fopen(ct_path, "wb");
		while (1) {
			int cnt = fread(plain, 1, 8, pf);
			if (cnt == 0) {
				break;
			}
			while (cnt < 8)
			{
				plain[cnt++] = 0;
			}
			des_ecb_encrypt((unsigned char*)plain, (unsigned char*)cipher, &skey);
			fwrite(cipher, 1, 8, cf);
		}
		fclose(pf);
		fclose(cf);
		return true;
	}
	else {
		yield("错误：非法密钥");
		return false;
	}
}

bool Cryptool::decryptDes(const char* ct_path, const char* pt_path, unsigned char* key) {
	if (!checkDesKey()) {
		return false;
	}
	symmetric_key skey;
	if (des_setup(key, 8, 16, &skey) == CRYPT_OK) {
		unsigned char plain[8];
		unsigned char cipher[8];
		FILE* pf = fopen(pt_path, "wb");
		FILE* cf = fopen(ct_path, "rb");
		while (1) {
			int cnt = fread(cipher, 1, 8, cf);
			if (cnt == 0) {
				break;
			}
			des_ecb_decrypt((unsigned char*)cipher, (unsigned char*)plain, &skey);
			fwrite(plain, 1, 8, pf);
		}
		fclose(pf);
		fclose(cf);
		return true;
	}
	else {
		yield("错误：非法密钥");
		return false;
	}
}

bool Cryptool::encryptAes(const char* pt_path, const char* ct_path, unsigned char* key) {
	if (!checkAesKey()) {
		return false;
	}
	unsigned char usrKeyArr[4][4];
	unsigned char exKeyArr[4][44];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			usrKeyArr[j][i] = key[i * 4 + j];
		}
	}
	keyExpansion(usrKeyArr, exKeyArr);
	unsigned char plain[16];
	unsigned char cipher[16];
	FILE* pf = fopen(pt_path, "rb");
	FILE* cf = fopen(ct_path, "wb");
	while (1) {
		int cnt = fread(plain, 1, 16, pf);
		if (cnt == 0) {
			break;
		}
		while (cnt < 16)
		{
			plain[cnt++] = 0;
		}
		unsigned char pArr[4][4];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				pArr[j][i] = plain[i * 4 + j];
			}
		}
		aes_ecb_encrypt(pArr, exKeyArr);
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				cipher[i * 4 + j] = pArr[j][i];
			}
		}
		fwrite(cipher, 1, 16, cf);
	}
	fclose(pf);
	fclose(cf);
	return true;
}

bool Cryptool::decryptAes(const char* ct_path, const char* pt_path, unsigned char* key) {
	if (!checkAesKey()) {
		return false;
	}
	unsigned char usrKeyArr[4][4];
	unsigned char exKeyArr[4][44];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			usrKeyArr[j][i] = key[i * 4 + j];
		}
	}
	keyExpansion(usrKeyArr, exKeyArr);
	unsigned char plain[16];
	unsigned char cipher[16];
	FILE* pf = fopen(pt_path, "wb");
	FILE* cf = fopen(ct_path, "rb");
	while (1) {
		int cnt = fread(cipher, 1, 16, cf);
		if (cnt == 0) {
			break;
		}
		while (cnt < 16)
		{
			cipher[cnt++] = 0;
		}
		unsigned char cArr[4][4];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				cArr[j][i] = cipher[i * 4 + j];
			}
		}
		aes_ecb_decrypt(cArr, exKeyArr);
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				plain[i * 4 + j] = cArr[j][i];
			}
		}
		fwrite(plain, 1, 16, pf);
	}
	fclose(pf);
	fclose(cf);
	return true;
}

void testAES() {
	unsigned char key[16] = { 0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f };
	unsigned char usrKeyArr[4][4];
	unsigned char exKeyArr[4][44];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			usrKeyArr[j][i] = key[i * 4 + j];
		}
	}
	keyExpansion(usrKeyArr, exKeyArr);
	unsigned char plainText[16] = "hahahhahahahaha";
	unsigned char cipherText[16];
	unsigned char pArr[4][4];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			pArr[j][i] = plainText[i * 4 + j];
		}
	}
	aes_ecb_encrypt(pArr, exKeyArr);
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			cipherText[i * 4 + j] = pArr[j][i];
		}
	}
	for (int i = 0; i < 16; i++) {
		printf("%c ", cipherText[i]);
	}
}