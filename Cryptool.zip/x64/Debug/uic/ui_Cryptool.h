/********************************************************************************
** Form generated from reading UI file 'Cryptool.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CRYPTOOL_H
#define UI_CRYPTOOL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CryptoolClass
{
public:
    QWidget *centralWidget;
    QPushButton *encryptBtn;
    QPushButton *decryptBtn;
    QLabel *statusLabel;
    QLabel *authorLabel;
    QGroupBox *chooseBox;
    QPushButton *kButton;
    QLineEdit *plainLine;
    QPushButton *pButton;
    QLabel *keyLaybel;
    QLineEdit *keyInput;
    QLineEdit *keyLine;
    QLineEdit *cipherLine;
    QPushButton *cButton;
    QGroupBox *paddingBox;
    QRadioButton *paddingBtn1;
    QRadioButton *paddingBtn2;
    QRadioButton *paddingBtn3;
    QGroupBox *modeBox;
    QRadioButton *modeBtn2;
    QRadioButton *modeBtn3;
    QRadioButton *modeBtn1;
    QRadioButton *modeBtn3_2;

    void setupUi(QMainWindow *CryptoolClass)
    {
        if (CryptoolClass->objectName().isEmpty())
            CryptoolClass->setObjectName("CryptoolClass");
        CryptoolClass->resize(432, 401);
        centralWidget = new QWidget(CryptoolClass);
        centralWidget->setObjectName("centralWidget");
        encryptBtn = new QPushButton(centralWidget);
        encryptBtn->setObjectName("encryptBtn");
        encryptBtn->setGeometry(QRect(29, 330, 161, 25));
        decryptBtn = new QPushButton(centralWidget);
        decryptBtn->setObjectName("decryptBtn");
        decryptBtn->setGeometry(QRect(230, 330, 171, 25));
        statusLabel = new QLabel(centralWidget);
        statusLabel->setObjectName("statusLabel");
        statusLabel->setGeometry(QRect(20, 370, 381, 17));
        authorLabel = new QLabel(centralWidget);
        authorLabel->setObjectName("authorLabel");
        authorLabel->setGeometry(QRect(300, 370, 121, 17));
        chooseBox = new QGroupBox(centralWidget);
        chooseBox->setObjectName("chooseBox");
        chooseBox->setGeometry(QRect(30, 10, 371, 191));
        kButton = new QPushButton(chooseBox);
        kButton->setObjectName("kButton");
        kButton->setGeometry(QRect(240, 110, 111, 25));
        plainLine = new QLineEdit(chooseBox);
        plainLine->setObjectName("plainLine");
        plainLine->setGeometry(QRect(20, 30, 181, 22));
        pButton = new QPushButton(chooseBox);
        pButton->setObjectName("pButton");
        pButton->setGeometry(QRect(240, 30, 111, 25));
        keyLaybel = new QLabel(chooseBox);
        keyLaybel->setObjectName("keyLaybel");
        keyLaybel->setGeometry(QRect(40, 150, 101, 16));
        keyInput = new QLineEdit(chooseBox);
        keyInput->setObjectName("keyInput");
        keyInput->setGeometry(QRect(170, 150, 181, 22));
        keyLine = new QLineEdit(chooseBox);
        keyLine->setObjectName("keyLine");
        keyLine->setGeometry(QRect(20, 110, 181, 22));
        cipherLine = new QLineEdit(chooseBox);
        cipherLine->setObjectName("cipherLine");
        cipherLine->setGeometry(QRect(20, 70, 181, 22));
        cButton = new QPushButton(chooseBox);
        cButton->setObjectName("cButton");
        cButton->setGeometry(QRect(240, 70, 111, 25));
        paddingBox = new QGroupBox(centralWidget);
        paddingBox->setObjectName("paddingBox");
        paddingBox->setGeometry(QRect(30, 270, 371, 51));
        paddingBtn1 = new QRadioButton(paddingBox);
        paddingBtn1->setObjectName("paddingBtn1");
        paddingBtn1->setGeometry(QRect(30, 20, 71, 21));
        paddingBtn2 = new QRadioButton(paddingBox);
        paddingBtn2->setObjectName("paddingBtn2");
        paddingBtn2->setGeometry(QRect(120, 20, 111, 21));
        paddingBtn3 = new QRadioButton(paddingBox);
        paddingBtn3->setObjectName("paddingBtn3");
        paddingBtn3->setGeometry(QRect(250, 20, 91, 21));
        modeBox = new QGroupBox(centralWidget);
        modeBox->setObjectName("modeBox");
        modeBox->setGeometry(QRect(30, 210, 371, 51));
        modeBtn2 = new QRadioButton(modeBox);
        modeBtn2->setObjectName("modeBtn2");
        modeBtn2->setGeometry(QRect(120, 20, 81, 21));
        modeBtn3 = new QRadioButton(modeBox);
        modeBtn3->setObjectName("modeBtn3");
        modeBtn3->setGeometry(QRect(210, 20, 81, 21));
        modeBtn1 = new QRadioButton(modeBox);
        modeBtn1->setObjectName("modeBtn1");
        modeBtn1->setGeometry(QRect(30, 20, 81, 21));
        modeBtn3_2 = new QRadioButton(modeBox);
        modeBtn3_2->setObjectName("modeBtn3_2");
        modeBtn3_2->setGeometry(QRect(300, 20, 81, 21));
        CryptoolClass->setCentralWidget(centralWidget);
        chooseBox->raise();
        encryptBtn->raise();
        decryptBtn->raise();
        statusLabel->raise();
        authorLabel->raise();
        paddingBox->raise();
        modeBox->raise();

        retranslateUi(CryptoolClass);

        QMetaObject::connectSlotsByName(CryptoolClass);
    } // setupUi

    void retranslateUi(QMainWindow *CryptoolClass)
    {
        CryptoolClass->setWindowTitle(QCoreApplication::translate("CryptoolClass", "Cryptool", nullptr));
        encryptBtn->setText(QCoreApplication::translate("CryptoolClass", "\345\212\240\345\257\206", nullptr));
        decryptBtn->setText(QCoreApplication::translate("CryptoolClass", "\350\247\243\345\257\206", nullptr));
        statusLabel->setText(QCoreApplication::translate("CryptoolClass", "\345\212\240\345\257\206\345\256\214\346\210\220\343\200\202", nullptr));
        authorLabel->setText(QCoreApplication::translate("CryptoolClass", " \351\255\217\346\214\257\346\235\26020241068", nullptr));
        chooseBox->setTitle(QCoreApplication::translate("CryptoolClass", "\346\226\207\344\273\266\351\200\211\346\213\251", nullptr));
        kButton->setText(QCoreApplication::translate("CryptoolClass", "\351\200\211\346\213\251\345\257\206\351\222\245\346\226\207\344\273\266", nullptr));
        plainLine->setText(QCoreApplication::translate("CryptoolClass", "select a file", nullptr));
        pButton->setText(QCoreApplication::translate("CryptoolClass", "\351\200\211\346\213\251\346\230\216\346\226\207\346\226\207\344\273\266", nullptr));
        keyLaybel->setText(QCoreApplication::translate("CryptoolClass", "\346\210\226\347\233\264\346\216\245\350\276\223\345\205\245\345\257\206\351\222\245\357\274\232", nullptr));
        keyInput->setText(QString());
        keyLine->setText(QCoreApplication::translate("CryptoolClass", "select a file", nullptr));
        cipherLine->setText(QCoreApplication::translate("CryptoolClass", "select a file", nullptr));
        cButton->setText(QCoreApplication::translate("CryptoolClass", "\351\200\211\346\213\251\345\257\206\346\226\207\346\226\207\344\273\266", nullptr));
        paddingBox->setTitle(QCoreApplication::translate("CryptoolClass", "\345\241\253\345\205\205\346\226\271\345\274\217", nullptr));
        paddingBtn1->setText(QCoreApplication::translate("CryptoolClass", "PKCS#7", nullptr));
        paddingBtn2->setText(QCoreApplication::translate("CryptoolClass", "ISO-9797-M2", nullptr));
        paddingBtn3->setText(QCoreApplication::translate("CryptoolClass", "ANSI-X9.23", nullptr));
        modeBox->setTitle(QCoreApplication::translate("CryptoolClass", "\345\267\245\344\275\234\346\226\271\345\274\217", nullptr));
        modeBtn2->setText(QCoreApplication::translate("CryptoolClass", "DES-CBC", nullptr));
        modeBtn3->setText(QCoreApplication::translate("CryptoolClass", "DES-OFB", nullptr));
        modeBtn1->setText(QCoreApplication::translate("CryptoolClass", "DES-ECB", nullptr));
        modeBtn3_2->setText(QCoreApplication::translate("CryptoolClass", "AES", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CryptoolClass: public Ui_CryptoolClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CRYPTOOL_H
